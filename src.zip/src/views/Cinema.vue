<template>
    <div>
        <div class="head">
            <div class="fanhui" @click="back">
                <router-link to="" style="color:#fff;">&lt;</router-link>
            </div>
            <div class="yyname">
                <span style="font-size:20px;">{{yy.ename}}</span>
            </div>
            <div class="right_img">
                <router-link to=""><img src="../assets/sousuo.png"></router-link>
                <router-link to=""><img src="../assets/sousuo.png"></router-link>
            </div>
        </div>
        <div class="zhuti">
            <div class="yyinfo">
                <div class="yyna">
                    <div class="yynal">
                        <h3 >{{yy.ename}}</h3>
                        <p>{{yy.site}}</p>
                    </div>
                    
                </div>
                <div class="yynar">
                    <p>&gt;</p> 
                </div>
            </div>
            <div class="taocan">
                <div>
                    <div>
                        <h4>观影套餐</h4>
                        <p>小吃、周边13.75元起</p>
                    </div>
                    <!-- <img src="" alt=""> -->
                </div>
                <div>
                    <h4>折扣卡</h4>
                    <p>开卡首单2张立减2元</p>
                </div>
            </div>
        </div>
        <div class="movieList" @scroll="handleScroll" ref='movielist' >
			<div ref="imglist" class="imageList" :style="{width:boxWidth+'rem',paddingLeft:boxPading+'rem',paddingRight:boxPading+'rem'}" >
				<div class="item" v-for="(item,index) in movieList" :key="index" :data-code="index">
					<div :style="{left:imgsleft[index]+'rem',top:imgstop[index]+'rem',width:imgwidth[index]+'%'}" ref="img" :data-mid="item.mid">
							<img :src="baseUrl+item.pic" alt="">
					</div>
						
				</div>
			</div>
				
		</div>
        <span :style="{left:spanleft+'rem'}"></span>
    </div>
</template>
<script>
export default {
    data(){
        return {
            cinema:{},
				//判断电影信息是否请求完成
			isloaded:0,
				// mid:this.theMid,
			baseUrl:baseUrl,
			MovieL:[],
				// hall:hall,
			movieList:[],
				//三角图标的left
			spanleft:(window.innerWidth)/24-0.8,
			winWidth:window.innerWidth,
				//图片元素的宽度比
				// imgswidth:0.8,
			imgsleft:[0.3,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7,0.7],
			imgstop:[0.4636,1.03,1.03,1.03,1.03,1.03,1.03,1.03,1.03,1.03,1.03,1.03,1.03,1.03,1.03],
			imgwidth:[90,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80,80],
            yy:{}
        }
    },
    props:["eid"],
    created(){
        this.getcinema();
        this.getmovielist();
    },
    methods:{
        getcinema(){
            var eid=this.eid;
            this.axios.get("movilist",{params:{eid}})
            .then(res=>{
                console.log(res)
                this.yy=res.data.data[0]
            })
        },
        getmovielist(){
            this.axios.get("movie")
            .then(res=>{
                console.log(res)
                this.movieList=res.data.data.movie;
            })
        },
        back(){
            this.$router.back();
        }
    }
}
</script>
<style scoped>
    .head{
        width:100%;
        height: 40px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        position:fixed;
        top:0;
        left:0;
        background-color: #f63939;
        font-size:20px;
        
    }
    .fanhui{
        width: 20%;
        text-align: left;
        margin-left: 10px;
        font-size:25px; 
    }
    .yyname{
        width:60%;
        color:#fff;
        font-size:22px
    }
    .right_img{
        width:20%;
        display: flex;
        justify-content: space-between;
        padding-right: 10px;
        align-items: center;
    }
    .right_img img{
        width: 25px;
    }
    .zhuti{
        margin-top:40px;
        display: flex;
        flex-direction:column;
        
    }
    .yyinfo{
        display: flex;
        justify-content: space-between;
        align-items: center
    }
    .yyna{
        width: 85%;
        text-align: left;
        padding:10px; 
    }
    .yynar{
        width: 15%;
        margin-right: 0;
    }
    .taocan{
        display:flex;
        justify-content: space-between
    }
    .taocan>div{
        border:1px solid #ccc;
        margin: 10px;
        width: 50%;
        color:rgb(73, 94, 64);
        padding-left: 5px;
        background-color:burlywood;
        text-align: left;
    }
</style>